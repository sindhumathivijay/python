EMAIL_USE_TLS = False
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'midhun.ppit@gmail.com'
EMAIL_HOST_PASSWORD= '123@Bc123'
EMAIL_PORT = 587