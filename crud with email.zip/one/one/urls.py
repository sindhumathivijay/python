
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from two import views

urlpatterns = [
    path('admin/', admin.site.urls),
    url('^$', views.show),
    url('^show', views.show),
    url('^add', views.add),
    url('^edit/(?P<id>\d+)$', views.edit),
    url('^delete/(?P<id>\d+)$', views.delete),
    url('^update/(?P<id>\d+)$', views.update),

]