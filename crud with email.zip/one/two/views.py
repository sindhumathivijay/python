from django.shortcuts import render,redirect
from two.models import data
from django.views.decorators.csrf import csrf_exempt
from one import settings
from django.conf import settings
from django.contrib import messages
from django.core.mail import send_mail

@csrf_exempt
def show(request):
    x=data.objects.all()
    return render(request,'show.html',{'x':x})

@csrf_exempt
def add(request):
    if request.method=='POST':
        name=request.POST['name']
        address=request.POST['address']
        email=request.POST['email']
        x=data(name=name,address=address,email=email)
        x.save()
        subject='Mail from ppit'
        messages='Thank you...!!! for u r registration...!!!'
        from_email=settings.EMAIL_HOST_USER
        to_email=[x.email,settings.EMAIL_HOST_USER]
        send_mail(subject,messages,from_email,to_email,fail_silently=True)
        print('mail send--------------------------->')


    return render(request,'add.html')

@csrf_exempt
def delete(request,id):
    x=data.objects.get(id=id)
    x.delete()
    return redirect('/')

@csrf_exempt
def edit(request,id):
    x=data.objects.get(id=id)
    return render(request,'edit.html',{'x':x})

@csrf_exempt
def update(request,id):
    if request.method == 'POST':
        x=data.objects.get(id=id)
        x.name = request.POST['name']
        x.address = request.POST['address']
        x.email = request.POST['email']
        x.save()
    return redirect('/')

