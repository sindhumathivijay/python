# import smtplib
# from smtplib import SMTPException
#
# sender = 'midhun.ppit@gmail.com'
# receivers = ['midhunram00@gmail.com']
#
# message = """From: From Person <midhun.ppit@gmail.com>
# To: To Person <midhunram00@gmail.com>
# Subject: SMTP e-mail test
#
# This is a test e-mail message.
# """
#
# try:
#    smtpObj = smtplib.SMTP('localhost')
#    smtpObj.sendmail(sender, receivers, message)
#    print ("Successfully sent email")
# except SMTPException:
#    print ("Error: unable to send email")



