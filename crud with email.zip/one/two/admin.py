from django.contrib import admin
from two.models import data


admin.site.register(data)
